# project-dchikkal-kyalaman-pveeram
Team Members : Deekshitha Chikkala, Keerthi Yalamanchili, Prabhitha Veeramachaneni


Link for the Dataset : https://www.kaggle.com/datasets/jainilcoder/online-payment-fraud-detection
